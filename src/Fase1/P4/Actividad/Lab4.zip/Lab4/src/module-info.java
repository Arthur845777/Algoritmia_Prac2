/**
 * 
 */
/**
 * 
 */
module Lab4 {
	requires java.desktop;
	
}